from google.cloud import storage

class Raptor:

    def __init__(self, name):
        self.name = name

    def wish(self):
        return f"Hello, {self.name}! Welcome to Meta Morph Package"

    def view_files(self, bucket_name):
        key_path = "meta-morph-d-eng-pro-admin.json"
        
        try:
            # Authenticate using the service account
            client = storage.Client.from_service_account_json(key_path)

            # Get the bucket
            bucket = client.bucket(bucket_name) 
            
            # List files in the bucket
            blobs = bucket.list_blobs()
            
            print(f"Files in bucket '{bucket_name}':")
            for blob in blobs:
                print(blob.name)
        
        except Exception as e:
            print(f"Error accessing bucket '{bucket_name}': {e}")
